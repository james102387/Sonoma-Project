let productJSON,
    productImages = {};


// Load data via ajax from local json file

function loadProducts(callback) {   

  let xhr = new XMLHttpRequest();
      xhr.overrideMimeType("application/json");

  xhr.open('GET', 'js/products.json', true);

  xhr.onreadystatechange = function () {
      if (xhr.readyState == 4 && xhr.status == "200") {
        callback(xhr.responseText);
      }
  };
  xhr.send(null);  
}


// Format the data from json source into data to be used by datatable

function formatData(json)
{
    let formattedData = [];
    productJSON.groups.forEach(function(product, index){

      let price,
          productData = {},
          productHTML;

      // Determine whether price or price range is being used

      if ("price" in product)
      {
        if (product.price.selling.toString().indexOf('.') !== -1)
        {
          price = product.price.selling.toFixed(2);
        }
        else
        {
          price = product.price.selling;
        }
      } 
      else
      {
        price = product.priceRange.selling.low+' - '+product.priceRange.selling.high;
      } 

      // Construct the product card html

      productHTML = `<div class="card-block1">
                          <figure>
                              <a class="grouped_elements" data-fancybox="group${product.id}" rel="${product.hero.rel}" href="${product.hero.href}" style="width: ${product.hero.width}; height: ${product.hero.height};">
                                <img data-id="${product.id}" src="${product.hero.href}" rel="${product.hero.rel}" style="height: ${product.hero.height}; width: ${product.hero.width};" alt="img1">
                              </a>
                               <a class="price" href="#">$${price}</a>
                               <a class="product-name"  href="#">${product.name}</a>
                          </figure>
                          <div class="card-cont">
                              <h2><a href="${product.links.www}">Buy Now!</a></h2>
                              <span style="display: block; font-size: 18px; font-weight: bold;">Avg. Rating: ${product.reviews.averageRating}</span>
                              <span style="display: block;">Reviews: ${product.reviews.reviewCount}</span>
                              <span style="display: block;">Recommendations: ${product.reviews.recommendationCount}</span>
                          </div>
                      </div>`;


      // Add images to global array

      if (product.images.length > 0) 
      {
        productImages[product.id] = product.images;
      }

      productData.html = productHTML;
      formattedData.push(productData);

    });

    return formattedData;
}


function init() {
 loadProducts(function(response) {
    productJSON = JSON.parse(response);
    let data = formatData(productJSON);

    // initiate data table with formatted data
    $('#product_table').DataTable({
        start: 0,
        pageLength: 9,
        paging: true,
        data: data,
        columns: [
            { data: 'html' }
        ],
        bPaginate: true,
        pagingType: 'full_numbers',
        sDom: 'rtp',
        drawCallback: function( settings ) {
          // Bind events and adjust css once table rendered
          $('.odd, .even').removeClass('col-sm-6 col-md-6 col-lg-4').addClass('col-sm-6 col-md-6 col-lg-4');
          $('#product_table').css('width','100%');
          $('.card-block1 img').off('click').on('click', function(){
            // On click, get image thumbnails for the product and initiate gallery
            let id = $(this).data('id'),
                thumbnails = productImages[id];

            $('.gallery').empty();
            if (typeof thumbnails !== undefined)
            {
              if (thumbnails.length > 0)
              {
                thumbnails.forEach(function(thumbnail){
                  let html = `<a class="grouped_elements" data-fancybox="group${id}" rel="${thumbnail.rel}" href="${thumbnail.href}" style="width: ${thumbnail.width}; height: ${thumbnail.height};">
                              </a>`;
                  $('.gallery').append(html);
                });  
              }
            }
            $("a.grouped_elements").fancybox();
          });
        }
    });

 });
}



$(document).ready(function(){
 init();
});